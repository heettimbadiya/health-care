import React from 'react';
import EditEmployeePage from "@/sections/employees/employeeEditForm";

function Page() {
    return (
        <>
          <EditEmployeePage/>
        </>
    );
}

export default Page;
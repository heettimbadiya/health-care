import React from 'react';
import EmployeeViewPage from "@/sections/employees/employee-view-page";

function Page() {
    return (
        <>
            <EmployeeViewPage/>
        </>
    );
}

export default Page;
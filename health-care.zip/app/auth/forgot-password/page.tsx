import React from 'react';
import ForgotPassword from "@/sections/auth/forgot-password";

function Page() {
    return (
        <>
          <ForgotPassword/>
        </>
    );
}

export default Page;
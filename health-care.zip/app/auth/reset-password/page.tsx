import React from 'react';
import ResetPassword from "@/sections/auth/reset-password";

function Page() {
    return (
        <>
          <ResetPassword/>
        </>
    );
}

export default Page;
import React from 'react';
import Login from "@/sections/auth/login";

function Page() {
    return (
        <>
          <Login/>
        </>
    );
}

export default Page;
export { default as AuthCard } from './AuthCard';
export type { AuthCardProps } from './AuthCard';

